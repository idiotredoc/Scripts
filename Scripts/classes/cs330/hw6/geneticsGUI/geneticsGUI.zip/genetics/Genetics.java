package genetics;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JApplet;
import javax.swing.JFrame;


public class Genetics extends JFrame
{

    private GeneticsView viewer;
    private JApplet applet;

    public Genetics(JApplet inApplet)
    {
	applet = inApplet;

	getContentPane().setLayout (new BorderLayout());
	viewer = new GeneticsView(this);

	/** Need to add the following components to the content pane
            - The viewer
	    - JTextField for entering # of generations
	       Changes to this should set maxGenerations in the 
               viewer accordingly
	    - Go button: pressing this should setGenerations in the viewer to 0
	    - Stop button: pressing this should setMaxGenerations in the
	       viewer to 0
	    - Reset button: pressing this should setMaxGenerations in the
	         viewer to 0 and then reset the viewer
	**/

	
	addWindowListener
	    (new WindowAdapter() {
		    public void windowClosing(WindowEvent e) {
			if (applet == null)
			    System.exit(0);
			else
			    dispose();
		    }
		});
    }
    

    public Dimension getPreferredSize()
    {
	return new Dimension(550, 550);
    }
    

    public static void main(String args[]) {
	Genetics window = new Genetics(null);
	window.setTitle("CS330 GUI Assignment");
	window.pack();
	window.setVisible(true);
    }

}
